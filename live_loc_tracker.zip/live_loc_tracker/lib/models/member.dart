class Member {
  final String id;
  final String name;

  const Member({required this.id, required this.name});
}
